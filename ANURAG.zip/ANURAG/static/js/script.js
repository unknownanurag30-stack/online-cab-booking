/* =========================================================
   ANURAG TRAVELS
   MAIN JAVASCRIPT
   ========================================================= */


/* =========================================================
   HELPER FUNCTIONS
   ========================================================= */

function showMessage(message, type = "error") {

    const messageBox =
        document.getElementById("message");

    if (!messageBox) {
        return;
    }

    messageBox.textContent = message;

    if (type === "success") {
        messageBox.style.color = "green";
    }
    else {
        messageBox.style.color = "red";
    }
}


/* =========================================================
   CUSTOMER LOGIN STATE
   ========================================================= */

function getLoggedInCustomer() {

    try {

        const customer =
            localStorage.getItem("customer");

        if (!customer) {
            return null;
        }

        return JSON.parse(customer);

    }
    catch (error) {

        console.error(
            "Customer data error:",
            error
        );

        return null;
    }
}


/* =========================================================
   UPDATE NAVBAR
   ========================================================= */

function updateNavbar() {

    const loggedOutLinks =
        document.getElementById(
            "loggedOutLinks"
        );

    const loggedInLinks =
        document.getElementById(
            "loggedInLinks"
        );


    if (!loggedOutLinks || !loggedInLinks) {
        return;
    }


    const customer =
        getLoggedInCustomer();


    if (customer) {

        loggedOutLinks.style.display =
            "none";

        loggedInLinks.style.display =
            "flex";

    }

    else {

        loggedOutLinks.style.display =
            "inline";

        loggedInLinks.style.display =
            "inline";

    }

}


/* =========================================================
   LOGOUT
   ========================================================= */

function setupLogout() {

    const logoutButton =
        document.getElementById(
            "logoutButton"
        );


    if (!logoutButton) {
        return;
    }


    logoutButton.addEventListener(
        "click",
        function(event) {

            event.preventDefault();


            localStorage.removeItem(
                "customer"
            );


            updateNavbar();


            window.location.href =
                "/";

        }
    );

}


/* =========================================================
   DATE FORMATTER
   ========================================================= */

function formatDate(dateValue) {

    if (!dateValue) {
        return "-";
    }


    try {

        const date =
            new Date(dateValue);


        if (isNaN(date.getTime())) {
            return dateValue;
        }


        return date.toLocaleDateString(
            "en-IN",
            {
                weekday: "short",
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );

    }

    catch (error) {

        return dateValue;

    }

}


/* =========================================================
   MONEY FORMATTER
   ========================================================= */

function formatMoney(amount) {

    if (
        amount === null ||
        amount === undefined ||
        amount === ""
    ) {
        return "₹0.00";
    }


    const number =
        Number(amount);


    if (isNaN(number)) {
        return "₹" + amount;
    }


    return "₹" +
        number.toLocaleString(
            "en-IN",
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

}


/* =========================================================
   SAFE VALUE
   ========================================================= */

function safeValue(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {
        return "-";
    }

    return value;

}


/* =========================================================
   CREATE DETAIL
   ========================================================= */

function createBookingDetail(
    label,
    value
) {

    return `

        <div class="booking-detail">

            <span class="booking-detail-label">
                ${label}
            </span>

            <span class="booking-detail-value">
                ${safeValue(value)}
            </span>

        </div>

    `;

}


/* =========================================================
   ACTIVE CAB BOOKING CARD
   ========================================================= */

function createCabBookingCard(
    booking
) {

    const vehicle =
        booking.vehicle || {};

    const driver =
        booking.driver || {};


    const bookingId =
        booking.booking_id ||
        booking.id ||
        "-";


    const vehicleModel =
        booking.vehicle_model ||
        vehicle.vehicle_model ||
        "-";


    const vehicleNumber =
        booking.vehicle_number ||
        vehicle.vehicle_number ||
        "-";


    const vehicleType =
        booking.vehicle_type ||
        vehicle.vehicle_type ||
        "-";


    const seating =
        booking.seating_capacity ||
        vehicle.seating_capacity ||
        "-";


    const driverName =
        booking.driver_name ||
        driver.name ||
        driver.driver_name ||
        "-";


    const driverPhone =
        booking.driver_phone ||
        driver.phone ||
        "-";


    const driverLicense =
        booking.license_number ||
        driver.license_number ||
        "-";


    const pickup =
        booking.pickup_location ||
        booking.pickup ||
        "-";


    const destination =
        booking.destination ||
        "-";


    const bookingDate =
        booking.booking_date ||
        booking.journey_date ||
        "-";


    const distance =
        booking.distance_km !== undefined
            ? booking.distance_km + " KM"
            : "-";


    const fare =
        formatMoney(
            booking.total_amount
        );


    const status =
        booking.booking_status ||
        booking.status ||
        "Confirmed";


    return `

        <div class="active-booking-card">

            <div class="booking-top">

                <div class="booking-title-area">

                    <div class="booking-type-label">
                        CAB BOOKING
                    </div>

                    <h2>
                        ${vehicleModel}
                    </h2>

                    <div class="booking-id">
                        BOOKING ID #${bookingId}
                    </div>

                </div>


                <div class="confirmed-badge">

                    <span class="confirmed-icon">
                        ✓
                    </span>

                    ${String(status).toUpperCase()}

                </div>

            </div>


            <div class="booking-grid">

                ${createBookingDetail(
                    "VEHICLE NUMBER",
                    vehicleNumber
                )}

                ${createBookingDetail(
                    "VEHICLE TYPE",
                    vehicleType
                )}

                ${createBookingDetail(
                    "JOURNEY DATE",
                    formatDate(bookingDate)
                )}

                ${createBookingDetail(
                    "SEATING",
                    seating + " Seats"
                )}

                ${createBookingDetail(
                    "PICKUP",
                    pickup
                )}

                ${createBookingDetail(
                    "DESTINATION",
                    destination
                )}

                ${createBookingDetail(
                    "DISTANCE",
                    distance
                )}

                ${createBookingDetail(
                    "BOOKING STATUS",
                    "Confirmed"
                )}

            </div>


            <div class="driver-box">

                <div class="driver-heading">
                    DRIVER DETAILS
                </div>


                <div class="driver-details">

                    <div>

                        <span class="booking-detail-label">
                            DRIVER NAME
                        </span>

                        <span class="booking-detail-value">
                            ${driverName}
                        </span>

                    </div>


                    <div>

                        <span class="booking-detail-label">
                            CONTACT
                        </span>

                        <span class="booking-detail-value">
                            ${driverPhone}
                        </span>

                    </div>

                </div>

            </div>


            <div class="fare-row">

                <span class="fare-label">
                    TOTAL FARE
                </span>

                <span class="fare-value">
                    ${fare}
                </span>

            </div>


            <div class="active-booking-actions">

                <a href="/my-bookings"
                   class="my-bookings-home-btn">

                    VIEW MY BOOKINGS →

                </a>

            </div>

        </div>

    `;

}


/* =========================================================
   ACTIVE TOUR BOOKING CARD
   ========================================================= */

function createTourBookingCard(
    booking
) {

    const bookingId =
        booking.tour_booking_id ||
        booking.booking_id ||
        booking.id ||
        "-";


    const packageName =
        booking.package_name ||
        booking.tour_package ||
        booking.package ||
        "Tour Package";


    const destination =
        booking.destination ||
        "-";


    const bookingDate =
        booking.booking_date ||
        "-";


    const people =
        booking.number_of_people ||
        booking.people ||
        "-";


    const amount =
        formatMoney(
            booking.total_amount
        );


    const status =
        booking.booking_status ||
        booking.status ||
        "Confirmed";


    return `

        <div class="active-booking-card">

            <div class="booking-top">

                <div class="booking-title-area">

                    <div class="booking-type-label">
                        TOUR BOOKING
                    </div>

                    <h2>
                        ${packageName}
                    </h2>

                    <div class="booking-id">
                        BOOKING ID #${bookingId}
                    </div>

                </div>


                <div class="confirmed-badge">

                    <span class="confirmed-icon">
                        ✓
                    </span>

                    ${String(status).toUpperCase()}

                </div>

            </div>


            <div class="booking-grid">

                ${createBookingDetail(
                    "DESTINATION",
                    destination
                )}

                ${createBookingDetail(
                    "JOURNEY DATE",
                    formatDate(bookingDate)
                )}

                ${createBookingDetail(
                    "NUMBER OF PEOPLE",
                    people
                )}

                ${createBookingDetail(
                    "BOOKING STATUS",
                    "Confirmed"
                )}

            </div>


            <div class="fare-row">

                <span class="fare-label">
                    TOTAL AMOUNT
                </span>

                <span class="fare-value">
                    ${amount}
                </span>

            </div>


            <div class="active-booking-actions">

                <a href="/my-bookings"
                   class="my-bookings-home-btn">

                    VIEW MY BOOKINGS →

                </a>

            </div>

        </div>

    `;

}


/* =========================================================
   ACTIVE DAILY RENTAL CARD
   ========================================================= */

function createDailyRentalCard(
    rental
) {

    const vehicle =
        rental.vehicle || {};


    const driver =
        rental.driver || {};


    const rentalId =
        rental.daily_rental_id ||
        rental.rental_id ||
        rental.id ||
        "-";


    const vehicleModel =
        rental.vehicle_model ||
        vehicle.vehicle_model ||
        "-";


    const vehicleNumber =
        rental.vehicle_number ||
        vehicle.vehicle_number ||
        "-";


    const vehicleType =
        rental.vehicle_type ||
        vehicle.vehicle_type ||
        "-";


    const seating =
        rental.seating_capacity ||
        vehicle.seating_capacity ||
        "-";


    const startDate =
        rental.start_date ||
        "-";


    const endDate =
        rental.end_date ||
        "-";


    const days =
        rental.rental_days ||
        "-";


    const driverName =
        rental.driver_name ||
        rental.driver?.driver_name ||
        driver.driver_name ||
        driver.name ||
        "-";


    const driverPhone =
        rental.driver_phone ||
        driver.phone ||
        "-";


    const carRate =
        rental.car_daily_rate ||
        0;


    const driverRate =
        rental.driver_daily_rate ||
        0;


    const totalAmount =
        rental.total_amount ||
        0;


    const fuelResponsibility =
        rental.fuel_responsibility ||
        "Customer";


    const status =
        rental.booking_status ||
        rental.status ||
        "Confirmed";


    return `

        <div class="active-booking-card">

            <div class="booking-top">

                <div class="booking-title-area">

                    <div class="booking-type-label">
                        DAILY CAR RENTAL
                    </div>

                    <h2>
                        ${vehicleModel}
                    </h2>

                    <div class="booking-id">
                        RENTAL ID #${rentalId}
                    </div>

                </div>


                <div class="confirmed-badge">

                    <span class="confirmed-icon">
                        ✓
                    </span>

                    ${String(status).toUpperCase()}

                </div>

            </div>


            <div class="booking-grid">

                ${createBookingDetail(
                    "VEHICLE NUMBER",
                    vehicleNumber
                )}

                ${createBookingDetail(
                    "VEHICLE TYPE",
                    vehicleType
                )}

                ${createBookingDetail(
                    "START DATE",
                    formatDate(startDate)
                )}

                ${createBookingDetail(
                    "END DATE",
                    formatDate(endDate)
                )}

                ${createBookingDetail(
                    "RENTAL DAYS",
                    days + " Days"
                )}

                ${createBookingDetail(
                    "SEATING",
                    seating + " Seats"
                )}

            </div>


            <div class="driver-box">

                <div class="driver-heading">
                    FIXED DRIVER
                </div>


                <div class="driver-details">

                    <div>

                        <span class="booking-detail-label">
                            DRIVER NAME
                        </span>

                        <span class="booking-detail-value">
                            ${driverName}
                        </span>

                    </div>


                    <div>

                        <span class="booking-detail-label">
                            CONTACT
                        </span>

                        <span class="booking-detail-value">
                            ${driverPhone}
                        </span>

                    </div>

                </div>

            </div>


            <div class="driver-box">

                <div class="driver-heading">
                    RENTAL PRICE BREAKDOWN
                </div>


                <div class="booking-grid">

                    ${createBookingDetail(
                        "CAR / DAY",
                        formatMoney(carRate)
                    )}

                    ${createBookingDetail(
                        "DRIVER / DAY",
                        formatMoney(driverRate)
                    )}

                    ${createBookingDetail(
                        "DAYS",
                        days
                    )}

                </div>

            </div>


            <div class="fare-row">

                <span class="fare-label">
                    TOTAL RENTAL AMOUNT
                </span>

                <span class="fare-value">
                    ${formatMoney(totalAmount)}
                </span>

            </div>


            <div style="
                margin-top:15px;
                font-size:13px;
                color:#555;
            ">

                ⛽ Fuel: ${fuelResponsibility}

            </div>


            <div class="active-booking-actions">

                <a href="/my-bookings"
                   class="my-bookings-home-btn">

                    VIEW MY BOOKINGS →

                </a>

            </div>

        </div>

    `;

}


/* =========================================================
   CHECK WHETHER BOOKING IS ACTIVE
   ========================================================= */

function isActiveBooking(
    booking
) {

    const status =
        String(
            booking.booking_status ||
            booking.status ||
            ""
        ).toLowerCase();


    return (
        status === "confirmed" ||
        status === "pending"
    );

}


/* =========================================================
   LOAD ACTIVE BOOKINGS
   ========================================================= */

async function loadActiveBookings() {

    const section =
        document.getElementById(
            "activeBookingSection"
        );


    const container =
        document.getElementById(
            "activeBookingsContainer"
        );


    if (!section || !container) {
        return;
    }


    const customer =
        getLoggedInCustomer();


    /*
       If user is not logged in,
       don't show active bookings.
    */

    if (!customer) {

        section.style.display =
            "none";

        return;

    }


    const customerId =
        customer.customer_id ||
        customer.id;


    if (!customerId) {

        section.style.display =
            "none";

        return;

    }


    let activeBookings = [];


    /* =====================================================
       CAB BOOKINGS
       ===================================================== */

    try {

        const response =
            await fetch(
                `/api/my-cab-bookings/${customerId}`
            );


        if (response.ok) {

            const data =
                await response.json();


            const cabBookings =
                Array.isArray(data)
                    ? data
                    : (
                        data.bookings ||
                        data.cab_bookings ||
                        []
                    );


            cabBookings
                .filter(
                    booking =>
                        isActiveBooking(
                            booking
                        )
                )
                .forEach(
                    booking => {

                        activeBookings.push({

                            type: "cab",

                            date:
                                booking.created_at ||
                                booking.booking_date ||
                                "",

                            booking:
                                booking

                        });

                    }
                );

        }

    }

    catch (error) {

        console.log(
            "Cab booking loading skipped:",
            error
        );

    }


    /* =====================================================
       TOUR BOOKINGS
       ===================================================== */

    try {

        const response =
            await fetch(
                `/api/my-tour-bookings/${customerId}`
            );


        if (response.ok) {

            const data =
                await response.json();


            const tourBookings =
                Array.isArray(data)
                    ? data
                    : (
                        data.bookings ||
                        data.tour_bookings ||
                        []
                    );


            tourBookings
                .filter(
                    booking =>
                        isActiveBooking(
                            booking
                        )
                )
                .forEach(
                    booking => {

                        activeBookings.push({

                            type: "tour",

                            date:
                                booking.created_at ||
                                booking.booking_date ||
                                "",

                            booking:
                                booking

                        });

                    }
                );

        }

    }

    catch (error) {

        console.log(
            "Tour booking loading skipped:",
            error
        );

    }


    /* =====================================================
       DAILY RENTALS
       ===================================================== */

    try {

        const response =
            await fetch(
                `/api/my-daily-rentals/${customerId}`
            );


        if (response.ok) {

            const data =
                await response.json();


            const dailyRentals =
                Array.isArray(data)
                    ? data
                    : (
                        data.rentals ||
                        data.daily_rentals ||
                        []
                    );


            dailyRentals
                .filter(
                    rental =>
                        isActiveBooking(
                            rental
                        )
                )
                .forEach(
                    rental => {

                        activeBookings.push({

                            type: "daily",

                            date:
                                rental.created_at ||
                                rental.start_date ||
                                "",

                            booking:
                                rental

                        });

                    }
                );

        }

    }

    catch (error) {

        /*
           If this API does not exist yet,
           the homepage simply ignores it.
        */

        console.log(
            "Daily rental loading skipped:",
            error
        );

    }


    /* =====================================================
       NO ACTIVE BOOKINGS
       ===================================================== */

    if (activeBookings.length === 0) {

        section.style.display =
            "none";

        return;

    }


    /* =====================================================
       SORT LATEST FIRST
       ===================================================== */

    activeBookings.sort(
        function(a, b) {

            return new Date(b.date || 0)
                -
                new Date(a.date || 0);

        }
    );


    /* =====================================================
       CREATE HTML
       ===================================================== */

    container.innerHTML = "";


    activeBookings.forEach(
        function(item) {

            let html = "";


            if (item.type === "cab") {

                html =
                    createCabBookingCard(
                        item.booking
                    );

            }


            else if (item.type === "tour") {

                html =
                    createTourBookingCard(
                        item.booking
                    );

            }


            else if (item.type === "daily") {

                html =
                    createDailyRentalCard(
                        item.booking
                    );

            }


            container.insertAdjacentHTML(
                "beforeend",
                html
            );

        }
    );


    section.style.display =
        "block";

}


/* =========================================================
   BOOKING PAGE
   ========================================================= */

const bookingForm =
    document.getElementById(
        "bookingForm"
    );


if (bookingForm) {


    const params =
        new URLSearchParams(
            window.location.search
        );


    const vehicleId =
        params.get("vehicle_id");


    const packageId =
        params.get("package_id");


    const customer =
        getLoggedInCustomer();


    const itemTitle =
        document.getElementById(
            "itemTitle"
        );


    const itemType =
        document.getElementById(
            "itemType"
        );


    const itemPrice =
        document.getElementById(
            "itemPrice"
        );


    const itemDuration =
        document.getElementById(
            "itemDuration"
        );


    const durationRow =
        document.getElementById(
            "durationRow"
        );


    const pickupGroup =
        document.getElementById(
            "pickupGroup"
        );


    const destinationGroup =
        document.getElementById(
            "destinationGroup"
        );


    const distanceGroup =
        document.getElementById(
            "distanceGroup"
        );


    const peopleGroup =
        document.getElementById(
            "peopleGroup"
        );


    const bookingButton =
        bookingForm.querySelector(
            ".booking-btn"
        );


    if (!customer) {

        alert(
            "Please login before making a booking."
        );


        window.location.href =
            "/login-page";

    }


    /* =====================================================
       CAB BOOKING
       ===================================================== */

    if (vehicleId) {


        pickupGroup.style.display =
            "block";


        destinationGroup.style.display =
            "block";


        distanceGroup.style.display =
            "block";


        peopleGroup.style.display =
            "none";


        fetch("/api/vehicles")

            .then(
                response => {

                    if (!response.ok) {

                        throw new Error(
                            "Unable to load vehicles."
                        );

                    }

                    return response.json();

                }
            )

            .then(
                data => {

                    const vehicles =
                        Array.isArray(data)
                            ? data
                            : data.vehicles || [];


                    const vehicle =
                        vehicles.find(
                            v =>
                                String(
                                    v.vehicle_id
                                )
                                ===
                                String(
                                    vehicleId
                                )
                        );


                    if (!vehicle) {

                        itemTitle.textContent =
                            "Vehicle not found";


                        showMessage(
                            "The selected vehicle could not be found."
                        );


                        return;

                    }


                    itemTitle.textContent =
                        vehicle.vehicle_model;


                    itemType.textContent =
                        vehicle.vehicle_type;


                    itemPrice.textContent =
                        "₹" +
                        vehicle.price_per_km +
                        " / km";


                    durationRow.style.display =
                        "none";

                }
            )

            .catch(
                error => {

                    console.error(
                        "Vehicle loading error:",
                        error
                    );


                    itemTitle.textContent =
                        "Unable to load vehicle";


                    showMessage(
                        "Unable to load vehicle details."
                    );

                }
            );

    }


    /* =====================================================
       TOUR BOOKING
       ===================================================== */

    else if (packageId) {


        pickupGroup.style.display =
            "none";


        destinationGroup.style.display =
            "none";


        distanceGroup.style.display =
            "none";


        peopleGroup.style.display =
            "block";


        fetch("/api/tour-packages")

            .then(
                response => {

                    if (!response.ok) {

                        throw new Error(
                            "Unable to load tour packages."
                        );

                    }

                    return response.json();

                }
            )

            .then(
                data => {

                    const packages =
                        Array.isArray(data)
                            ? data
                            : data.packages || [];


                    const pkg =
                        packages.find(
                            p =>
                                String(
                                    p.package_id
                                )
                                ===
                                String(
                                    packageId
                                )
                        );


                    if (!pkg) {

                        itemTitle.textContent =
                            "Tour package not found";


                        showMessage(
                            "The selected tour package could not be found."
                        );


                        return;

                    }


                    itemTitle.textContent =
                        pkg.package_name;


                    itemType.textContent =
                        pkg.destination;


                    itemPrice.textContent =
                        "₹" +
                        pkg.package_price +
                        " / person";


                    itemDuration.textContent =
                        pkg.duration_days +
                        " Days";


                    durationRow.style.display =
                        "flex";

                }
            )

            .catch(
                error => {

                    console.error(
                        "Tour package loading error:",
                        error
                    );


                    itemTitle.textContent =
                        "Unable to load tour package";


                    showMessage(
                        "Unable to load tour package details."
                    );

                }
            );

    }


    /* =====================================================
       FORM SUBMISSION
       ===================================================== */

    bookingForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            if (!customer) {

                showMessage(
                    "Please login before making a booking."
                );

                return;

            }


            const bookingDate =
                document.getElementById(
                    "bookingDate"
                ).value;


            if (!bookingDate) {

                showMessage(
                    "Please select a booking date."
                );

                return;

            }


            /* =================================================
               CAB
               ================================================= */

            if (vehicleId) {


                const pickup =
                    document.getElementById(
                        "pickup"
                    ).value.trim();


                const destination =
                    document.getElementById(
                        "destination"
                    ).value.trim();


                const distance =
                    document.getElementById(
                        "distance"
                    ).value;


                if (!pickup) {

                    showMessage(
                        "Please enter pickup location."
                    );

                    return;

                }


                if (!destination) {

                    showMessage(
                        "Please enter destination."
                    );

                    return;

                }


                if (
                    !distance ||
                    Number(distance) <= 0
                ) {

                    showMessage(
                        "Please enter a valid distance."
                    );

                    return;

                }


                bookingButton.disabled =
                    true;


                bookingButton.textContent =
                    "PROCESSING...";


                try {

                    const response =
                        await fetch(
                            "/api/book-cab",
                            {

                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body: JSON.stringify({

                                    customer_id:
                                        customer.customer_id,

                                    vehicle_id:
                                        Number(vehicleId),

                                    pickup_location:
                                        pickup,

                                    destination:
                                        destination,

                                    booking_date:
                                        bookingDate,

                                    distance_km:
                                        Number(distance)

                                })

                            }
                        );


                    const result =
                        await response.json();


                    if (result.success) {


                        showMessage(
                            "✓ Cab booked successfully! " +
                            "Total amount: ₹" +
                            result.total_amount,
                            "success"
                        );


                        /*
                           Store latest customer again
                           so homepage knows who is logged in.
                        */

                        localStorage.setItem(
                            "customer",
                            JSON.stringify(
                                customer
                            )
                        );


                        bookingButton.textContent =
                            "VIEW MY BOOKINGS";


                        bookingButton.disabled =
                            false;


                        bookingButton.onclick =
                            function() {

                                window.location.href =
                                    "/my-bookings";

                            };


                        const inputs =
                            bookingForm.querySelectorAll(
                                "input"
                            );


                        inputs.forEach(
                            input => {

                                input.disabled =
                                    true;

                            }
                        );

                    }

                    else {

                        showMessage(
                            result.message ||
                            "Cab booking failed."
                        );


                        bookingButton.disabled =
                            false;


                        bookingButton.textContent =
                            "CONFIRM BOOKING";

                    }

                }

                catch (error) {

                    console.error(
                        "Cab booking error:",
                        error
                    );


                    showMessage(
                        "Server error. Please try again."
                    );


                    bookingButton.disabled =
                        false;


                    bookingButton.textContent =
                        "CONFIRM BOOKING";

                }

            }


            /* =================================================
               TOUR
               ================================================= */

            else if (packageId) {


                const numberOfPeople =
                    document.getElementById(
                        "numberOfPeople"
                    ).value;


                if (
                    !numberOfPeople ||
                    Number(numberOfPeople) < 1
                ) {

                    showMessage(
                        "Please enter a valid number of people."
                    );

                    return;

                }


                bookingButton.disabled =
                    true;


                bookingButton.textContent =
                    "PROCESSING...";


                try {

                    const response =
                        await fetch(
                            "/api/book-tour",
                            {

                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body: JSON.stringify({

                                    customer_id:
                                        customer.customer_id,

                                    package_id:
                                        Number(packageId),

                                    booking_date:
                                        bookingDate,

                                    number_of_people:
                                        Number(numberOfPeople)

                                })

                            }
                        );


                    const result =
                        await response.json();


                    if (result.success) {


                        showMessage(
                            "✓ Tour booked successfully! " +
                            "Total amount: ₹" +
                            result.total_amount,
                            "success"
                        );


                        localStorage.setItem(
                            "customer",
                            JSON.stringify(
                                customer
                            )
                        );


                        bookingButton.textContent =
                            "VIEW MY BOOKINGS";


                        bookingButton.disabled =
                            false;


                        bookingButton.onclick =
                            function() {

                                window.location.href =
                                    "/my-bookings";

                            };


                        const inputs =
                            bookingForm.querySelectorAll(
                                "input"
                            );


                        inputs.forEach(
                            input => {

                                input.disabled =
                                    true;

                            }
                        );

                    }

                    else {

                        showMessage(
                            result.message ||
                            "Tour booking failed."
                        );


                        bookingButton.disabled =
                            false;


                        bookingButton.textContent =
                            "CONFIRM BOOKING";

                    }

                }

                catch (error) {

                    console.error(
                        "Tour booking error:",
                        error
                    );


                    showMessage(
                        "Server error. Please try again."
                    );


                    bookingButton.disabled =
                        false;


                    bookingButton.textContent =
                        "CONFIRM BOOKING";

                }

            }


            else {

                showMessage(
                    "No vehicle or tour package was selected."
                );

            }

        }
    );

}


/* =========================================================
   CABS PAGE
   ========================================================= */

const cabContainer =
    document.getElementById(
        "cab-container"
    );


if (cabContainer) {


    async function loadCabs() {

        try {

            const response =
                await fetch(
                    "/api/vehicles"
                );


            if (!response.ok) {

                throw new Error(
                    "Unable to load vehicles"
                );

            }


            const data =
                await response.json();


            const vehicles =
                Array.isArray(data)
                    ? data
                    : data.vehicles || [];


            cabContainer.innerHTML =
                "";


            if (vehicles.length === 0) {

                cabContainer.innerHTML = `

                    <div class="loading">

                        No cabs are currently available.

                    </div>

                `;

                return;

            }


            vehicles.forEach(
                vehicle => {


                    const card =
                        document.createElement(
                            "div"
                        );


                    card.className =
                        "cab-card";


                    const totalCars =
                        Number(
                            vehicle.total_cars || 0
                        );


                    const availableCars =
                        Number(
                            vehicle.available_cars || 0
                        );


                    const fullyBooked =
                        availableCars <= 0;


                    let availabilityHTML;


                    if (fullyBooked) {

                        availabilityHTML = `

                            <strong class="fully-booked">

                                FULLY BOOKED

                            </strong>

                        `;

                    }

                    else {

                        availabilityHTML = `

                            <strong class="available-count">

                                ${availableCars}

                                ${
                                    availableCars === 1
                                        ? "Car"
                                        : "Cars"
                                }

                                Available

                            </strong>

                        `;

                    }


                    let buttonHTML;


                    if (fullyBooked) {

                        buttonHTML = `

                            <span
                                class="book-btn disabled"
                            >

                                FULLY BOOKED

                            </span>

                        `;

                    }

                    else {

                        buttonHTML = `

                            <a
                                href="/booking?vehicle_id=${vehicle.vehicle_id}"
                                class="book-btn"
                            >

                                Book This Cab

                            </a>

                        `;

                    }


                    card.innerHTML = `

                        <div class="cab-icon">
                            🚕
                        </div>


                        <h2>
                            ${vehicle.vehicle_model}
                        </h2>


                        <div class="cab-number">
                            ${vehicle.vehicle_number}
                        </div>


                        <div class="cab-info">


                            <div>

                                <span>
                                    Type
                                </span>

                                <strong>
                                    ${vehicle.vehicle_type}
                                </strong>

                            </div>


                            <div>

                                <span>
                                    Seats
                                </span>

                                <strong>
                                    ${vehicle.seating_capacity}
                                </strong>

                            </div>


                            <div>

                                <span>
                                    Fleet
                                </span>

                                <strong>

                                    ${totalCars}

                                    ${
                                        totalCars === 1
                                            ? "Car"
                                            : "Cars"
                                    }

                                </strong>

                            </div>


                            <div>

                                <span>
                                    Availability
                                </span>

                                ${availabilityHTML}

                            </div>


                        </div>


                        <div class="cab-price">

                            ₹${vehicle.price_per_km}

                            <span>
                                / km
                            </span>

                        </div>


                        ${buttonHTML}

                    `;


                    cabContainer.appendChild(
                        card
                    );

                }
            );

        }

        catch (error) {

            console.error(
                "Cab loading error:",
                error
            );


            cabContainer.innerHTML = `

                <div class="error-message">

                    Unable to load available cabs.
                    Please check the server and
                    database connection.

                </div>

            `;

        }

    }


    loadCabs();

}


/* =========================================================
   PAGE INITIALIZATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        updateNavbar();

        setupLogout();

        loadActiveBookings();

    }
);