from flask import Flask, render_template, request, jsonify
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)


# =====================================================
# DATABASE CONNECTION
# =====================================================

def get_db_connection():

    try:

        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Dfganurag@7",
            database="cab_rental_db",
            port=3306
        )

        return connection

    except Error as e:

        print("Database connection error:", e)

        return None


# =====================================================
# HOME PAGE
# =====================================================

@app.route("/")
def home():

    return render_template("index.html")


# =====================================================
# CABS PAGE
# =====================================================

@app.route("/cabs")
def cabs():

    return render_template("cabs.html")


# =====================================================
# REGISTER PAGE
# =====================================================

@app.route("/register")
def register_page():

    return render_template("register.html")


# =====================================================
# LOGIN PAGE
# =====================================================

@app.route("/login-page")
def login_page():

    return render_template("login.html")


# =====================================================
# TOURS PAGE
# =====================================================

@app.route("/tours")
def tours():

    return render_template("tours.html")


# =====================================================
# BOOKING PAGE
# =====================================================

@app.route("/booking")
def booking():

    return render_template("booking.html")


# =====================================================
# DAILY CAR RENTAL PAGE
# =====================================================

@app.route("/daily-rental")
def daily_rental():

    return render_template("daily_rental.html")


# =====================================================
# MY BOOKINGS PAGE
# =====================================================

@app.route("/my-bookings")
def my_bookings():

    return render_template("my_bookings.html")


# =====================================================
# ADMIN PAGE
# =====================================================

@app.route("/admin")
def admin():

    return render_template("admin.html")


# =====================================================
# GET ALL VEHICLES
#
# ALL vehicle models are returned.
#
# Even when available_cars = 0,
# the vehicle remains visible.
# =====================================================

@app.route("/api/vehicles", methods=["GET"])
def get_vehicles():

    connection = get_db_connection()

    if connection is None:

        return jsonify({
            "success": False,
            "message": "Could not connect to database"
        }), 500

    cursor = connection.cursor(dictionary=True)

    try:

        cursor.execute("""
            SELECT
                vehicle_id,
                vehicle_number,
                vehicle_model,
                vehicle_type,
                seating_capacity,
                price_per_km,
                availability,
                total_cars,
                available_cars
            FROM vehicles
            ORDER BY vehicle_id
        """)

        vehicles = cursor.fetchall()

        return jsonify(vehicles)

    except Error as e:

        print("Vehicle fetch error:", e)

        return jsonify({
            "success": False,
            "message": "Unable to fetch vehicles"
        }), 500

    finally:

        cursor.close()
        connection.close()


# =====================================================
# DAILY RENTAL - GET AVAILABLE PHYSICAL CARS
#
# Each physical car is connected permanently to
# one driver through fleet_cars.
#
# Example:
#
# PB01AB1234 -> Raj Kumar
# PB01AB5678 -> Aman Singh
#
# Availability is checked using rental dates.
# =====================================================

@app.route("/api/daily-rental-vehicles", methods=["GET"])
def daily_rental_vehicles():

    start_date = request.args.get("start_date")
    end_date = request.args.get("end_date")

    # -------------------------------------------------
    # BASIC DATE VALIDATION
    # -------------------------------------------------

    if not start_date or not end_date:

        return jsonify({
            "success": False,
            "error": "Start date and end date are required"
        }), 400


    connection = get_db_connection()

    if connection is None:

        return jsonify({
            "success": False,
            "error": "Database connection failed"
        }), 500


    cursor = connection.cursor(dictionary=True)

    try:

        # -------------------------------------------------
        # CHECK DATE ORDER
        # -------------------------------------------------

        cursor.execute("""
            SELECT DATEDIFF(%s, %s) AS difference
        """, (
            end_date,
            start_date
        ))

        date_result = cursor.fetchone()

        difference = int(
            date_result["difference"]
        )


        if difference < 0:

            return jsonify({
                "success": False,
                "error":
                    "End date cannot be before start date"
            }), 400


        # -------------------------------------------------
        # GET ALL PHYSICAL CARS
        #
        # Each car has its fixed driver.
        # -------------------------------------------------

        cursor.execute("""
            SELECT

                fc.fleet_car_id,

                fc.vehicle_number,

                v.vehicle_id,

                v.vehicle_model,

                v.vehicle_type,

                v.seating_capacity,

                v.daily_car_rate,

                v.daily_driver_rate,

                d.driver_id,

                d.driver_name,

                d.phone AS driver_phone,

                d.license_number

            FROM fleet_cars fc

            INNER JOIN vehicles v
                ON fc.vehicle_id =
                   v.vehicle_id

            INNER JOIN drivers d
                ON fc.driver_id =
                   d.driver_id

            ORDER BY
                v.vehicle_id,
                fc.fleet_car_id

        """)


        cars = cursor.fetchall()


        # -------------------------------------------------
        # CHECK EACH PHYSICAL CAR
        # -------------------------------------------------

        for car in cars:

            cursor.execute("""
                SELECT
                    daily_rental_id
                FROM daily_rentals

                WHERE fleet_car_id = %s

                AND booking_status IN
                    ('Pending', 'Confirmed')

                AND start_date <= %s

                AND end_date >= %s

                LIMIT 1

            """, (
                car["fleet_car_id"],
                end_date,
                start_date
            ))


            existing_booking = cursor.fetchone()


            if existing_booking:

                car["available"] = False

            else:

                car["available"] = True


            # -------------------------------------------------
            # DAILY COMBINED PRICE
            # -------------------------------------------------

            car_daily_rate = float(
                car["daily_car_rate"]
            )

            driver_daily_rate = float(
                car["daily_driver_rate"]
            )


            car["daily_total"] = round(
                car_daily_rate +
                driver_daily_rate,
                2
            )


        return jsonify({

            "success": True,

            "start_date": start_date,

            "end_date": end_date,

            "cars": cars

        })


    except Error as e:

        print(
            "Daily rental availability error:",
            e
        )

        return jsonify({
            "success": False,
            "error":
                "Unable to check daily rental availability"
        }), 500


    finally:

        cursor.close()
        connection.close()


# =====================================================
# BOOK DAILY CAR RENTAL
#
# CUSTOMER SELECTS:
#
# 1. Physical car
# 2. Start date
# 3. End date
#
# Driver is automatically assigned because every
# physical car already has a fixed driver.
#
# Fuel = Customer Responsibility
#
# Pricing:
#
# Car daily rate
# +
# Driver daily rate
# =
# Daily rental cost
# =====================================================

@app.route("/api/book-daily-rental", methods=["POST"])
def book_daily_rental():

    data = request.get_json()


    if not data:

        return jsonify({
            "success": False,
            "error": "Invalid request"
        }), 400


    # =================================================
    # GET BOOKING DATA
    # =================================================

    customer_id = data.get("customer_id")

    fleet_car_id = data.get("fleet_car_id")

    start_date = data.get("start_date")

    end_date = data.get("end_date")


    # =================================================
    # BASIC VALIDATION
    # =================================================

    if not all([
        customer_id,
        fleet_car_id,
        start_date,
        end_date
    ]):

        return jsonify({
            "success": False,
            "error":
                "Customer, car and rental dates are required"
        }), 400


    connection = get_db_connection()


    if connection is None:

        return jsonify({
            "success": False,
            "error":
                "Database connection failed"
        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        # =================================================
        # CHECK CUSTOMER
        # =================================================

        cursor.execute("""
            SELECT

                customer_id,

                name,

                phone,

                email

            FROM customers

            WHERE customer_id = %s

        """, (
            customer_id,
        ))


        customer = cursor.fetchone()


        if customer is None:

            connection.rollback()

            return jsonify({
                "success": False,
                "error":
                    "Customer not found"
            }), 404


        # =================================================
        # CHECK DATE RANGE
        # =================================================

        cursor.execute("""
            SELECT
                DATEDIFF(%s, %s) AS difference
        """, (
            end_date,
            start_date
        ))


        date_result = cursor.fetchone()


        difference = int(
            date_result["difference"]
        )


        if difference < 0:

            connection.rollback()

            return jsonify({
                "success": False,
                "error":
                    "End date cannot be before start date"
            }), 400


        # =================================================
        # RENTAL DAYS
        #
        # Example:
        #
        # 18 Sep -> 18 Sep = 1 day
        # 18 Sep -> 19 Sep = 2 days
        # =================================================

        rental_days = difference + 1


        # =================================================
        # GET SELECTED PHYSICAL CAR
        #
        # FOR UPDATE locks this car during booking.
        # =================================================

        cursor.execute("""
            SELECT

                fc.fleet_car_id,

                fc.vehicle_number,

                v.vehicle_id,

                v.vehicle_model,

                v.vehicle_type,

                v.seating_capacity,

                v.daily_car_rate,

                v.daily_driver_rate,

                d.driver_id,

                d.driver_name,

                d.phone AS driver_phone,

                d.license_number

            FROM fleet_cars fc

            INNER JOIN vehicles v
                ON fc.vehicle_id =
                   v.vehicle_id

            INNER JOIN drivers d
                ON fc.driver_id =
                   d.driver_id

            WHERE fc.fleet_car_id = %s

            FOR UPDATE

        """, (
            fleet_car_id,
        ))


        car = cursor.fetchone()


        # =================================================
        # CAR NOT FOUND
        # =================================================

        if car is None:

            connection.rollback()

            return jsonify({
                "success": False,
                "error":
                    "Selected car was not found"
            }), 404


        # =================================================
        # CHECK OVERLAPPING RENTAL
        #
        # Existing:
        # 20 -> 25
        #
        # New:
        # 22 -> 27
        #
        # OVERLAP = NOT AVAILABLE
        # =================================================

        cursor.execute("""
            SELECT

                daily_rental_id,

                start_date,

                end_date

            FROM daily_rentals

            WHERE fleet_car_id = %s

            AND booking_status IN
                ('Pending', 'Confirmed')

            AND start_date <= %s

            AND end_date >= %s

            LIMIT 1

        """, (
            fleet_car_id,
            end_date,
            start_date
        ))


        overlapping_booking = cursor.fetchone()


        if overlapping_booking:

            connection.rollback()

            return jsonify({
                "success": False,
                "error":
                    "This car is already booked for the selected dates."
            }), 400


        # =================================================
        # CALCULATE PRICES
        # =================================================

        car_daily_rate = float(
            car["daily_car_rate"]
        )

        driver_daily_rate = float(
            car["daily_driver_rate"]
        )


        daily_total = (

            car_daily_rate

            +

            driver_daily_rate

        )


        total_amount = (

            daily_total

            *

            rental_days

        )


        # =================================================
        # CREATE DAILY RENTAL BOOKING
        # =================================================

        cursor.execute("""
            INSERT INTO daily_rentals
            (
                customer_id,

                fleet_car_id,

                start_date,

                end_date,

                rental_days,

                car_daily_rate,

                driver_daily_rate,

                total_amount,

                fuel_responsibility,

                booking_status
            )

            VALUES
            (
                %s,

                %s,

                %s,

                %s,

                %s,

                %s,

                %s,

                %s,

                %s,

                %s
            )

        """, (

            customer_id,

            fleet_car_id,

            start_date,

            end_date,

            rental_days,

            car_daily_rate,

            driver_daily_rate,

            total_amount,

            "Customer",

            "Confirmed"

        ))


        daily_rental_id = cursor.lastrowid


        # =================================================
        # COMMIT
        # =================================================

        connection.commit()


        # =================================================
        # RETURN COMPLETE BOOKING
        # =================================================

        return jsonify({

            "success": True,

            "message":
                "Daily car rental booked successfully",

            "daily_rental_id":
                daily_rental_id,

            "start_date":
                str(start_date),

            "end_date":
                str(end_date),

            "rental_days":
                rental_days,


            # =============================================
            # VEHICLE
            # =============================================

            "vehicle": {

                "fleet_car_id":
                    car["fleet_car_id"],

                "vehicle_id":
                    car["vehicle_id"],

                "vehicle_number":
                    car["vehicle_number"],

                "vehicle_model":
                    car["vehicle_model"],

                "vehicle_type":
                    car["vehicle_type"],

                "seating_capacity":
                    car["seating_capacity"]

            },


            # =============================================
            # FIXED DRIVER
            # =============================================

            "driver": {

                "driver_id":
                    car["driver_id"],

                "name":
                    car["driver_name"],

                "phone":
                    car["driver_phone"],

                "license_number":
                    car["license_number"]

            },


            # =============================================
            # PRICING
            # =============================================

            "pricing": {

                "car_daily_rate":
                    round(
                        car_daily_rate,
                        2
                    ),

                "driver_daily_rate":
                    round(
                        driver_daily_rate,
                        2
                    ),

                "daily_total":
                    round(
                        daily_total,
                        2
                    ),

                "rental_days":
                    rental_days,

                "total_amount":
                    round(
                        total_amount,
                        2
                    ),

                "fuel":
                    "Customer Responsibility"

            }

        }), 201


    except Error as e:

        connection.rollback()

        print(
            "Daily rental booking error:",
            e
        )

        return jsonify({

            "success": False,

            "error":
                str(e)

        }), 400


    finally:

        cursor.close()

        connection.close()


# =====================================================
# GET TOUR PACKAGES
# =====================================================

@app.route("/api/tour-packages", methods=["GET"])
def get_tour_packages():

    connection = get_db_connection()

    if connection is None:

        return jsonify({
            "success": False,
            "message":
                "Could not connect to database"
        }), 500

    cursor = connection.cursor(
        dictionary=True
    )

    try:

        cursor.execute("""
            SELECT

                package_id,

                package_name,

                destination,

                duration_days,

                description,

                package_price,

                availability

            FROM tour_packages

            WHERE availability = TRUE

        """)


        packages = cursor.fetchall()


        return jsonify(packages)


    except Error as e:

        print(
            "Tour package fetch error:",
            e
        )

        return jsonify({

            "success": False,

            "message":
                "Unable to fetch tour packages"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# CUSTOMER REGISTRATION
# =====================================================

@app.route("/api/register", methods=["POST"])
def register():

    data = request.get_json()


    if not data:

        return jsonify({
            "success": False,
            "error":
                "Invalid request"
        }), 400


    name = data.get("name")

    phone = data.get("phone")

    email = data.get("email")

    password = data.get("password")


    if not name or not phone or not email or not password:

        return jsonify({
            "success": False,
            "error":
                "All fields are required"
        }), 400


    connection = get_db_connection()


    if connection is None:

        return jsonify({
            "success": False,
            "error":
                "Database connection failed"
        }), 500


    cursor = connection.cursor()


    try:

        cursor.execute("""
            INSERT INTO customers
            (
                name,

                phone,

                email,

                password
            )

            VALUES
            (
                %s,

                %s,

                %s,

                %s
            )

        """, (
            name,

            phone,

            email,

            password
        ))


        connection.commit()


        customer_id = cursor.lastrowid


        return jsonify({

            "success": True,

            "message":
                "Registration successful",

            "customer_id":
                customer_id

        }), 201


    except Error as e:

        connection.rollback()


        print(
            "Registration error:",
            e
        )


        return jsonify({

            "success": False,

            "error":
                str(e)

        }), 400


    finally:

        cursor.close()

        connection.close()


# =====================================================
# CUSTOMER LOGIN
# =====================================================

@app.route("/api/login", methods=["POST"])
def login():

    data = request.get_json()


    if not data:

        return jsonify({

            "success": False,

            "error":
                "Invalid request"

        }), 400


    email = data.get("email")

    password = data.get("password")


    if not email or not password:

        return jsonify({

            "success": False,

            "error":
                "Email and password are required"

        }), 400


    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "success": False,

            "error":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                customer_id,

                name,

                phone,

                email

            FROM customers

            WHERE email = %s

            AND password = %s

        """, (
            email,

            password
        ))


        customer = cursor.fetchone()


        if customer:

            return jsonify({

                "success": True,

                "message":
                    "Login successful",

                "customer":
                    customer

            })


        return jsonify({

            "success": False,

            "error":
                "Invalid email or password"

        }), 401


    except Error as e:

        print(
            "Login error:",
            e
        )


        return jsonify({

            "success": False,

            "error":
                "Login failed"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# CAB BOOKING
#
# EXISTING SYSTEM PRESERVED
# =====================================================

@app.route("/api/book-cab", methods=["POST"])
def book_cab():

    data = request.get_json()


    if not data:

        return jsonify({

            "success": False,

            "error":
                "Invalid request"

        }), 400


    customer_id = data.get("customer_id")

    vehicle_id = data.get("vehicle_id")

    pickup_location = data.get("pickup_location")

    destination = data.get("destination")

    booking_date = data.get("booking_date")

    distance_km = data.get("distance_km")


    if not all([
        customer_id,

        vehicle_id,

        pickup_location,

        destination,

        booking_date,

        distance_km

    ]):

        return jsonify({

            "success": False,

            "error":
                "All booking fields are required"

        }), 400


    try:

        distance_km = float(
            distance_km
        )


        if distance_km <= 0:

            return jsonify({

                "success": False,

                "error":
                    "Distance must be greater than zero"

            }), 400


    except (ValueError, TypeError):

        return jsonify({

            "success": False,

            "error":
                "Invalid distance"

        }), 400


    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "success": False,

            "error":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        # CHECK CUSTOMER

        cursor.execute("""
            SELECT

                customer_id,

                name,

                phone,

                email

            FROM customers

            WHERE customer_id = %s

        """, (
            customer_id,
        ))


        customer = cursor.fetchone()


        if customer is None:

            connection.rollback()

            return jsonify({

                "success": False,

                "error":
                    "Customer not found"

            }), 404


        # LOCK VEHICLE

        cursor.execute("""
            SELECT

                vehicle_id,

                vehicle_number,

                vehicle_model,

                vehicle_type,

                seating_capacity,

                price_per_km,

                total_cars,

                available_cars

            FROM vehicles

            WHERE vehicle_id = %s

            FOR UPDATE

        """, (
            vehicle_id,
        ))


        vehicle = cursor.fetchone()


        if vehicle is None:

            connection.rollback()

            return jsonify({

                "success": False,

                "error":
                    "Vehicle not found"

            }), 404


        available_cars = int(
            vehicle["available_cars"]
        )


        if available_cars <= 0:

            connection.rollback()

            return jsonify({

                "success": False,

                "error":
                    vehicle["vehicle_model"]
                    + " is fully booked."

            }), 400


        # FIND DRIVER

        cursor.execute("""
            SELECT

                driver_id,

                driver_name,

                phone,

                license_number

            FROM drivers

            WHERE availability = TRUE

            ORDER BY driver_id

            LIMIT 1

            FOR UPDATE

        """)


        driver = cursor.fetchone()


        if driver is None:

            connection.rollback()

            return jsonify({

                "success": False,

                "error":
                    "No driver is currently available."

            }), 400


        # CALCULATE FARE

        price_per_km = float(
            vehicle["price_per_km"]
        )


        total_amount = (

            price_per_km

            *

            distance_km

        )


        # INSERT BOOKING

        cursor.execute("""
            INSERT INTO cab_bookings
            (
                customer_id,

                vehicle_id,

                driver_id,

                pickup_location,

                destination,

                booking_date,

                distance_km,

                total_amount,

                booking_status
            )

            VALUES
            (
                %s,

                %s,

                %s,

                %s,

                %s,

                %s,

                %s,

                %s,

                %s
            )

        """, (

            customer_id,

            vehicle_id,

            driver["driver_id"],

            pickup_location,

            destination,

            booking_date,

            distance_km,

            total_amount,

            "Confirmed"

        ))


        booking_id = cursor.lastrowid


        # DECREASE AVAILABLE CARS

        cursor.execute("""
            UPDATE vehicles

            SET available_cars =
                available_cars - 1

            WHERE vehicle_id = %s

            AND available_cars > 0

        """, (
            vehicle_id,
        ))


        new_available_cars = (
            available_cars - 1
        )


        # UPDATE AVAILABILITY

        cursor.execute("""
            UPDATE vehicles

            SET availability = %s

            WHERE vehicle_id = %s

        """, (

            new_available_cars > 0,

            vehicle_id

        ))


        # MARK DRIVER UNAVAILABLE

        cursor.execute("""
            UPDATE drivers

            SET availability = FALSE

            WHERE driver_id = %s

        """, (
            driver["driver_id"],
        ))


        connection.commit()


        return jsonify({

            "success": True,

            "message":
                "Cab booking successful",

            "booking_id":
                booking_id,

            "booking_status":
                "Confirmed",

            "booking_date":
                str(booking_date),

            "pickup_location":
                pickup_location,

            "destination":
                destination,

            "distance_km":
                round(
                    distance_km,
                    2
                ),

            "total_amount":
                round(
                    total_amount,
                    2
                ),

            "vehicle": {

                "vehicle_id":
                    vehicle["vehicle_id"],

                "vehicle_number":
                    vehicle["vehicle_number"],

                "vehicle_model":
                    vehicle["vehicle_model"],

                "vehicle_type":
                    vehicle["vehicle_type"],

                "seating_capacity":
                    vehicle["seating_capacity"]

            },

            "driver": {

                "driver_id":
                    driver["driver_id"],

                "name":
                    driver["driver_name"],

                "phone":
                    driver["phone"],

                "license_number":
                    driver["license_number"]

            },

            "fleet": {

                "total_cars":
                    int(
                        vehicle["total_cars"]
                    ),

                "remaining_cars":
                    new_available_cars,

                "fully_booked":
                    new_available_cars == 0

            }

        }), 201


    except Error as e:

        connection.rollback()


        print(
            "Cab booking error:",
            e
        )


        return jsonify({

            "success": False,

            "error":
                str(e)

        }), 400


    finally:

        cursor.close()

        connection.close()


# =====================================================
# TOUR BOOKING
# =====================================================

@app.route("/api/book-tour", methods=["POST"])
def book_tour():

    data = request.get_json()


    if not data:

        return jsonify({

            "success": False,

            "message":
                "Invalid request"

        }), 400


    customer_id = data.get("customer_id")

    package_id = data.get("package_id")

    booking_date = data.get("booking_date")

    number_of_people = data.get(
        "number_of_people"
    )


    if not all([
        customer_id,

        package_id,

        booking_date,

        number_of_people

    ]):

        return jsonify({

            "success": False,

            "message":
                "All tour booking fields are required"

        }), 400


    try:

        number_of_people = int(
            number_of_people
        )


        if number_of_people < 1:

            return jsonify({

                "success": False,

                "message":
                    "Number of people must be at least 1"

            }), 400


    except (ValueError, TypeError):

        return jsonify({

            "success": False,

            "message":
                "Invalid number of people"

        }), 400


    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "success": False,

            "message":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                package_id,

                package_name,

                destination,

                duration_days,

                package_price,

                availability

            FROM tour_packages

            WHERE package_id = %s

        """, (
            package_id,
        ))


        package = cursor.fetchone()


        if package is None:

            connection.rollback()

            return jsonify({

                "success": False,

                "message":
                    "Tour package not found"

            }), 404


        if not package["availability"]:

            connection.rollback()

            return jsonify({

                "success": False,

                "message":
                    "Tour package is not available"

            }), 400


        total_amount = (

            float(
                package["package_price"]
            )

            *

            number_of_people

        )


        cursor.execute("""
            INSERT INTO tour_bookings
            (
                customer_id,

                package_id,

                booking_date,

                number_of_people,

                total_amount,

                booking_status
            )

            VALUES
            (
                %s,

                %s,

                %s,

                %s,

                %s,

                %s
            )

        """, (

            customer_id,

            package_id,

            booking_date,

            number_of_people,

            total_amount,

            "Confirmed"

        ))


        tour_booking_id = cursor.lastrowid


        connection.commit()


        return jsonify({

            "success": True,

            "message":
                "Tour booking successful",

            "booking_id":
                tour_booking_id,

            "total_amount":
                round(
                    total_amount,
                    2
                )

        }), 201


    except Error as e:

        connection.rollback()


        print(
            "Tour booking error:",
            e
        )


        return jsonify({

            "success": False,

            "message":
                str(e)

        }), 400


    finally:

        cursor.close()

        connection.close()


# =====================================================
# CUSTOMER - CAB BOOKINGS
#
# RETURNS DRIVER INFORMATION
# =====================================================

@app.route(
    "/api/my-cab-bookings/<int:customer_id>",
    methods=["GET"]
)
def my_cab_bookings(customer_id):

    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "success": False,

            "message":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                cb.booking_id,

                cb.booking_date,

                cb.pickup_location,

                cb.destination,

                cb.distance_km,

                cb.total_amount,

                cb.booking_status,

                v.vehicle_model,

                v.vehicle_type,

                v.vehicle_number,

                v.seating_capacity,

                d.driver_name,

                d.phone AS driver_phone,

                d.license_number

            FROM cab_bookings cb

            INNER JOIN vehicles v

                ON cb.vehicle_id =
                   v.vehicle_id

            LEFT JOIN drivers d

                ON cb.driver_id =
                   d.driver_id

            WHERE cb.customer_id = %s

            ORDER BY
                cb.created_at DESC

        """, (
            customer_id,
        ))


        bookings = cursor.fetchall()


        return jsonify({

            "success": True,

            "bookings":
                bookings

        })


    except Error as e:

        print(
            "Cab booking fetch error:",
            e
        )


        return jsonify({

            "success": False,

            "message":
                "Unable to load cab bookings"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# CUSTOMER - TOUR BOOKINGS
# =====================================================

@app.route(
    "/api/my-tour-bookings/<int:customer_id>",
    methods=["GET"]
)
def my_tour_bookings(customer_id):

    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "success": False,

            "message":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                tb.tour_booking_id,

                tb.booking_date,

                tb.number_of_people,

                tb.total_amount,

                tb.booking_status,

                tp.package_name,

                tp.destination,

                tp.duration_days

            FROM tour_bookings tb

            INNER JOIN tour_packages tp

                ON tb.package_id =
                   tp.package_id

            WHERE tb.customer_id = %s

            ORDER BY
                tb.created_at DESC

        """, (
            customer_id,
        ))


        bookings = cursor.fetchall()


        return jsonify({

            "success": True,

            "bookings":
                bookings

        })


    except Error as e:

        print(
            "Tour booking fetch error:",
            e
        )


        return jsonify({

            "success": False,

            "message":
                "Unable to load tour bookings"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# CUSTOMER - OLD CAB BOOKINGS API
# =====================================================

@app.route(
    "/api/customer-bookings/<int:customer_id>",
    methods=["GET"]
)
def customer_bookings(customer_id):

    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "error":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                cb.booking_id,

                cb.pickup_location,

                cb.destination,

                cb.booking_date,

                cb.distance_km,

                cb.total_amount,

                cb.booking_status,

                v.vehicle_model,

                v.vehicle_number,

                d.driver_name,

                d.phone AS driver_phone

            FROM cab_bookings cb

            JOIN vehicles v

                ON cb.vehicle_id =
                   v.vehicle_id

            LEFT JOIN drivers d

                ON cb.driver_id =
                   d.driver_id

            WHERE cb.customer_id = %s

            ORDER BY
                cb.created_at DESC

        """, (
            customer_id,
        ))


        bookings = cursor.fetchall()


        return jsonify(bookings)


    except Error as e:

        print(
            "Customer bookings error:",
            e
        )


        return jsonify({

            "error":
                "Unable to fetch bookings"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# CUSTOMER - DAILY RENTAL BOOKINGS
# =====================================================

@app.route(
    "/api/my-daily-rentals/<int:customer_id>",
    methods=["GET"]
)
def my_daily_rentals(customer_id):

    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "success": False,

            "message":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                dr.daily_rental_id,

                dr.start_date,

                dr.end_date,

                dr.rental_days,

                dr.car_daily_rate,

                dr.driver_daily_rate,

                dr.total_amount,

                dr.fuel_responsibility,

                dr.booking_status,

                dr.created_at,

                v.vehicle_model,

                v.vehicle_type,

                v.seating_capacity,

                fc.vehicle_number,

                d.driver_name,

                d.phone AS driver_phone,

                d.license_number

            FROM daily_rentals dr

            INNER JOIN fleet_cars fc

                ON dr.fleet_car_id =
                   fc.fleet_car_id

            INNER JOIN vehicles v

                ON fc.vehicle_id =
                   v.vehicle_id

            INNER JOIN drivers d

                ON fc.driver_id =
                   d.driver_id

            WHERE dr.customer_id = %s

            ORDER BY
                dr.created_at DESC

        """, (
            customer_id,
        ))


        rentals = cursor.fetchall()


        return jsonify({

            "success": True,

            "rentals":
                rentals

        })


    except Error as e:

        print(
            "Daily rental fetch error:",
            e
        )


        return jsonify({

            "success": False,

            "message":
                "Unable to load daily rentals"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# ADMIN - GET ALL CUSTOMERS
# =====================================================

@app.route(
    "/api/admin/customers",
    methods=["GET"]
)
def admin_customers():

    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "error":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                customer_id,

                name,

                phone,

                email,

                created_at

            FROM customers

            ORDER BY
                created_at DESC

        """)


        customers = cursor.fetchall()


        return jsonify(customers)


    except Error as e:

        print(
            "Admin customer error:",
            e
        )


        return jsonify({

            "error":
                "Unable to fetch customers"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# ADMIN - GET ALL CAB BOOKINGS
#
# SHOWS DRIVER
# =====================================================

@app.route(
    "/api/admin/bookings",
    methods=["GET"]
)
def admin_bookings():

    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "error":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                cb.booking_id,

                c.name AS customer_name,

                c.phone,

                v.vehicle_number,

                v.vehicle_model,

                v.vehicle_type,

                cb.pickup_location,

                cb.destination,

                cb.booking_date,

                cb.distance_km,

                cb.total_amount,

                cb.booking_status,

                d.driver_name,

                d.phone AS driver_phone,

                d.license_number

            FROM cab_bookings cb

            JOIN customers c

                ON cb.customer_id =
                   c.customer_id

            JOIN vehicles v

                ON cb.vehicle_id =
                   v.vehicle_id

            LEFT JOIN drivers d

                ON cb.driver_id =
                   d.driver_id

            ORDER BY
                cb.created_at DESC

        """)


        bookings = cursor.fetchall()


        return jsonify(bookings)


    except Error as e:

        print(
            "Admin booking error:",
            e
        )


        return jsonify({

            "error":
                "Unable to fetch bookings"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# ADMIN - GET ALL DAILY RENTALS
# =====================================================

@app.route(
    "/api/admin/daily-rentals",
    methods=["GET"]
)
def admin_daily_rentals():

    connection = get_db_connection()


    if connection is None:

        return jsonify({

            "success": False,

            "error":
                "Database connection failed"

        }), 500


    cursor = connection.cursor(
        dictionary=True
    )


    try:

        cursor.execute("""
            SELECT

                dr.daily_rental_id,

                c.name AS customer_name,

                c.phone AS customer_phone,

                c.email AS customer_email,

                fc.vehicle_number,

                v.vehicle_model,

                v.vehicle_type,

                dr.start_date,

                dr.end_date,

                dr.rental_days,

                dr.car_daily_rate,

                dr.driver_daily_rate,

                dr.total_amount,

                dr.fuel_responsibility,

                dr.booking_status,

                d.driver_name,

                d.phone AS driver_phone,

                d.license_number,

                dr.created_at

            FROM daily_rentals dr

            INNER JOIN customers c

                ON dr.customer_id =
                   c.customer_id

            INNER JOIN fleet_cars fc

                ON dr.fleet_car_id =
                   fc.fleet_car_id

            INNER JOIN vehicles v

                ON fc.vehicle_id =
                   v.vehicle_id

            INNER JOIN drivers d

                ON fc.driver_id =
                   d.driver_id

            ORDER BY
                dr.created_at DESC

        """)


        rentals = cursor.fetchall()


        return jsonify({

            "success": True,

            "rentals":
                rentals

        })


    except Error as e:

        print(
            "Admin daily rental error:",
            e
        )


        return jsonify({

            "success": False,

            "error":
                "Unable to fetch daily rentals"

        }), 500


    finally:

        cursor.close()

        connection.close()


# =====================================================
# START SERVER
# =====================================================

if __name__ == "__main__":

    app.run(

        debug=True,

        host="127.0.0.1",

        port=5000

    )