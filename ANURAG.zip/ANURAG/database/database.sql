-- ==========================================
-- CAB RENTAL & TOUR TRAVELS MANAGEMENT SYSTEM
-- ==========================================

CREATE DATABASE IF NOT EXISTS cab_rental_db;

USE cab_rental_db;


-- ==========================================
-- 1. CUSTOMERS
-- ==========================================

CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ==========================================
-- 2. VEHICLES
-- ==========================================

CREATE TABLE vehicles (
    vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_number VARCHAR(20) NOT NULL UNIQUE,
    vehicle_model VARCHAR(100) NOT NULL,
    vehicle_type VARCHAR(50) NOT NULL,
    seating_capacity INT NOT NULL,
    price_per_km DECIMAL(10,2) NOT NULL,
    availability BOOLEAN DEFAULT TRUE
);


-- ==========================================
-- 3. TOUR PACKAGES
-- ==========================================

CREATE TABLE tour_packages (
    package_id INT AUTO_INCREMENT PRIMARY KEY,
    package_name VARCHAR(150) NOT NULL,
    destination VARCHAR(150) NOT NULL,
    duration_days INT NOT NULL,
    description TEXT,
    package_price DECIMAL(10,2) NOT NULL,
    availability BOOLEAN DEFAULT TRUE
);


-- ==========================================
-- 4. CAB BOOKINGS
-- ==========================================

CREATE TABLE cab_bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,

    customer_id INT NOT NULL,
    vehicle_id INT NOT NULL,

    pickup_location VARCHAR(255) NOT NULL,
    destination VARCHAR(255) NOT NULL,

    booking_date DATE NOT NULL,

    distance_km DECIMAL(10,2),
    total_amount DECIMAL(10,2),

    booking_status ENUM(
        'Pending',
        'Confirmed',
        'Completed',
        'Cancelled'
    ) DEFAULT 'Pending',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
        ON DELETE CASCADE,

    FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(vehicle_id)
        ON DELETE CASCADE
);


-- ==========================================
-- 5. TOUR BOOKINGS
-- ==========================================

CREATE TABLE tour_bookings (
    tour_booking_id INT AUTO_INCREMENT PRIMARY KEY,

    customer_id INT NOT NULL,
    package_id INT NOT NULL,

    booking_date DATE NOT NULL,

    number_of_people INT NOT NULL,

    total_amount DECIMAL(10,2),

    booking_status ENUM(
        'Pending',
        'Confirmed',
        'Completed',
        'Cancelled'
    ) DEFAULT 'Pending',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
        ON DELETE CASCADE,

    FOREIGN KEY (package_id)
        REFERENCES tour_packages(package_id)
        ON DELETE CASCADE
);


-- ==========================================
-- 6. ADMINS
-- ==========================================

CREATE TABLE admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,

    username VARCHAR(50) NOT NULL UNIQUE,

    password VARCHAR(255) NOT NULL
);


-- ==========================================
-- SAMPLE VEHICLES
-- ==========================================

INSERT INTO vehicles
(
    vehicle_number,
    vehicle_model,
    vehicle_type,
    seating_capacity,
    price_per_km,
    availability
)
VALUES
(
    'PB01AB1234',
    'Toyota Etios',
    'Sedan',
    4,
    14.00,
    TRUE
),
(
    'PB01CD5678',
    'Maruti Ertiga',
    'SUV',
    6,
    18.00,
    TRUE
),
(
    'PB01EF9012',
    'Toyota Innova',
    'SUV',
    7,
    22.00,
    TRUE
),
(
    'PB01GH3456',
    'Swift Dzire',
    'Sedan',
    4,
    12.00,
    TRUE
);


-- ==========================================
-- SAMPLE TOUR PACKAGES
-- ==========================================

INSERT INTO tour_packages
(
    package_name,
    destination,
    duration_days,
    description,
    package_price,
    availability
)
VALUES
(
    'Manali Adventure',
    'Manali',
    5,
    'Complete Manali sightseeing and adventure tour.',
    15000.00,
    TRUE
),
(
    'Shimla Holiday',
    'Shimla',
    4,
    'Shimla sightseeing with nearby attractions.',
    12000.00,
    TRUE
),
(
    'Amritsar Heritage Tour',
    'Amritsar',
    2,
    'Golden Temple and important local attractions.',
    6000.00,
    TRUE
),
(
    'Goa Beach Tour',
    'Goa',
    5,
    'Complete Goa beach and sightseeing package.',
    18000.00,
    TRUE
);


-- ==========================================
-- SAMPLE ADMIN
-- ==========================================

INSERT INTO admins
(
    username,
    password
)
VALUES
(
    'admin',
    'admin123'
);


-- ==========================================
-- CHECK TABLES
-- ==========================================

SHOW TABLES;

CREATE TABLE IF NOT EXISTS tour_bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    package_id INT NOT NULL,
    booking_date DATE NOT NULL,
    pickup_location VARCHAR(255),
    destination VARCHAR(255),
    total_amount DECIMAL(10,2),
    booking_status VARCHAR(50) DEFAULT 'Confirmed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id),

    FOREIGN KEY (package_id)
        REFERENCES tour_packages(package_id)
);